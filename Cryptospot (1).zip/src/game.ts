import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../df8d742f-045c-4fe3-8c70-adfb47d22baf/src/item"
import Script2 from "../132c8f9d-5faa-4e14-b985-44562ccacc24/src/item"
import Script3 from "../7402ef02-fc7f-4e19-b44a-4613ee2526c5/src/item"
import Script4 from "../ff9257ec-9d62-404f-97c7-cf19c4035761/src/item"
import Script5 from "../689705e0-fff4-4b3a-b31a-98d8cc3230b8/src/item"
import Script6 from "../c5cbd030-54d0-4f28-9158-d27401c691b1/src/item"
import Script7 from "../37e449e5-9298-41b6-8c9a-a6d12b45bdd2/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const cornerStoneBrickWall = new Entity('cornerStoneBrickWall')
engine.addEntity(cornerStoneBrickWall)
cornerStoneBrickWall.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(15.5, 0, 0.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("models/Module_Stone_Curve_01/Module_Stone_Curve_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
cornerStoneBrickWall.addComponentOrReplace(gltfShape)

const cornerStoneBrickWall2 = new Entity('cornerStoneBrickWall2')
engine.addEntity(cornerStoneBrickWall2)
cornerStoneBrickWall2.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(0.5, 0, 16),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall2.addComponentOrReplace(transform3)
cornerStoneBrickWall2.addComponentOrReplace(gltfShape)

const cornerStoneBrickWall3 = new Entity('cornerStoneBrickWall3')
engine.addEntity(cornerStoneBrickWall3)
cornerStoneBrickWall3.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(15.5, 0, 12.5),
  rotation: new Quaternion(-6.692902301134779e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.000016450881958, 1, 1.000016450881958)
})
cornerStoneBrickWall3.addComponentOrReplace(transform4)
cornerStoneBrickWall3.addComponentOrReplace(gltfShape)

const cornerStoneBrickWall4 = new Entity('cornerStoneBrickWall4')
engine.addEntity(cornerStoneBrickWall4)
cornerStoneBrickWall4.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(7.5, 0, 0.5),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000050067901611, 1, 1.0000050067901611)
})
cornerStoneBrickWall4.addComponentOrReplace(transform5)
cornerStoneBrickWall4.addComponentOrReplace(gltfShape)

const stoneArchway = new Entity('stoneArchway')
engine.addEntity(stoneArchway)
stoneArchway.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(15, 0, 6.5),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000061988830566, 1, 1.0000061988830566)
})
stoneArchway.addComponentOrReplace(transform6)
const gltfShape2 = new GLTFShape("models/ArchWay_02/ArchWay_02.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
stoneArchway.addComponentOrReplace(gltfShape2)

const scroll = new Entity('scroll')
engine.addEntity(scroll)
scroll.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(3.5, 1, 13),
  rotation: new Quaternion(-0.04436416178941727, -0.15250346064567566, 0.03259103372693062, -0.9867686629295349),
  scale: new Vector3(1.01359224319458, 1.0000040531158447, 1.1149466037750244)
})
scroll.addComponentOrReplace(transform7)

const druidWoodenRoundTable = new Entity('druidWoodenRoundTable')
engine.addEntity(druidWoodenRoundTable)
druidWoodenRoundTable.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(3, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.265625, 1.5)
})
druidWoodenRoundTable.addComponentOrReplace(transform8)
const gltfShape3 = new GLTFShape("models/WoodRoundTable_01/WoodRoundTable_01.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
druidWoodenRoundTable.addComponentOrReplace(gltfShape3)

const cornerStoneBrickWall5 = new Entity('cornerStoneBrickWall5')
engine.addEntity(cornerStoneBrickWall5)
cornerStoneBrickWall5.setParent(_scene)
cornerStoneBrickWall5.addComponentOrReplace(gltfShape)
const transform9 = new Transform({
  position: new Vector3(12, 0, 12),
  rotation: new Quaternion(8.698221416859512e-23, 1.4901161193847656e-8, -1.9050029328798127e-15, -1),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall5.addComponentOrReplace(transform9)

const cornerStoneBrickWall6 = new Entity('cornerStoneBrickWall6')
engine.addEntity(cornerStoneBrickWall6)
cornerStoneBrickWall6.setParent(_scene)
cornerStoneBrickWall6.addComponentOrReplace(gltfShape)
const transform10 = new Transform({
  position: new Vector3(2.5, 0, 15.5),
  rotation: new Quaternion(-4.127578846475997e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.000002384185791, 1, 1.000002384185791)
})
cornerStoneBrickWall6.addComponentOrReplace(transform10)

const cornerStoneBrickWall7 = new Entity('cornerStoneBrickWall7')
engine.addEntity(cornerStoneBrickWall7)
cornerStoneBrickWall7.setParent(_scene)
cornerStoneBrickWall7.addComponentOrReplace(gltfShape)
const transform11 = new Transform({
  position: new Vector3(15, 0, 16),
  rotation: new Quaternion(-1.1610725300312003e-14, 0, -1.389234152791418e-14, -1),
  scale: new Vector3(1.0000026226043701, 1, 1.0000026226043701)
})
cornerStoneBrickWall7.addComponentOrReplace(transform11)

const cornerStoneBrickWall8 = new Entity('cornerStoneBrickWall8')
engine.addEntity(cornerStoneBrickWall8)
cornerStoneBrickWall8.setParent(_scene)
cornerStoneBrickWall8.addComponentOrReplace(gltfShape)
const transform12 = new Transform({
  position: new Vector3(0.5, 0, 8),
  rotation: new Quaternion(4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall8.addComponentOrReplace(transform12)

const cornerStoneBrickWall9 = new Entity('cornerStoneBrickWall9')
engine.addEntity(cornerStoneBrickWall9)
cornerStoneBrickWall9.setParent(_scene)
cornerStoneBrickWall9.addComponentOrReplace(gltfShape)
const transform13 = new Transform({
  position: new Vector3(7, 0, 12.5),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall9.addComponentOrReplace(transform13)

const cornerStoneBrickWall10 = new Entity('cornerStoneBrickWall10')
engine.addEntity(cornerStoneBrickWall10)
cornerStoneBrickWall10.setParent(_scene)
cornerStoneBrickWall10.addComponentOrReplace(gltfShape)
const transform14 = new Transform({
  position: new Vector3(2.5, 0, 23.5),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall10.addComponentOrReplace(transform14)

const cornerStoneBrickWall11 = new Entity('cornerStoneBrickWall11')
engine.addEntity(cornerStoneBrickWall11)
cornerStoneBrickWall11.setParent(_scene)
cornerStoneBrickWall11.addComponentOrReplace(gltfShape)
const transform15 = new Transform({
  position: new Vector3(4, 0, 4),
  rotation: new Quaternion(4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall11.addComponentOrReplace(transform15)

const cornerStoneBrickWall12 = new Entity('cornerStoneBrickWall12')
engine.addEntity(cornerStoneBrickWall12)
cornerStoneBrickWall12.setParent(_scene)
cornerStoneBrickWall12.addComponentOrReplace(gltfShape)
const transform16 = new Transform({
  position: new Vector3(6.5, 0, 27),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall12.addComponentOrReplace(transform16)

const cornerStoneBrickWall13 = new Entity('cornerStoneBrickWall13')
engine.addEntity(cornerStoneBrickWall13)
cornerStoneBrickWall13.setParent(_scene)
cornerStoneBrickWall13.addComponentOrReplace(gltfShape)
const transform17 = new Transform({
  position: new Vector3(11, 0, 27),
  rotation: new Quaternion(4.127578846475997e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(1.000002384185791, 1, 1.000002384185791)
})
cornerStoneBrickWall13.addComponentOrReplace(transform17)

const cornerStoneBrickWall14 = new Entity('cornerStoneBrickWall14')
engine.addEntity(cornerStoneBrickWall14)
cornerStoneBrickWall14.setParent(_scene)
cornerStoneBrickWall14.addComponentOrReplace(gltfShape)
const transform18 = new Transform({
  position: new Vector3(15, 0, 24),
  rotation: new Quaternion(4.127578846475997e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
cornerStoneBrickWall14.addComponentOrReplace(transform18)

const curlyMagicBeanSprout = new Entity('curlyMagicBeanSprout')
engine.addEntity(curlyMagicBeanSprout)
curlyMagicBeanSprout.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(11.5, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3, 5, 1.5)
})
curlyMagicBeanSprout.addComponentOrReplace(transform19)
const gltfShape4 = new GLTFShape("models/Vegetation_05/Vegetation_05.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
curlyMagicBeanSprout.addComponentOrReplace(gltfShape4)

const greenAcaciaTree = new Entity('greenAcaciaTree')
engine.addEntity(greenAcaciaTree)
greenAcaciaTree.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(4, 0, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenAcaciaTree.addComponentOrReplace(transform20)
const gltfShape5 = new GLTFShape("models/Tree_Forest_Green_01/Tree_Forest_Green_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
greenAcaciaTree.addComponentOrReplace(gltfShape5)

const stalagmite = new Entity('stalagmite')
engine.addEntity(stalagmite)
stalagmite.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(9, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.294999599456787, 6.75, 1.9999996423721313)
})
stalagmite.addComponentOrReplace(transform21)
const gltfShape6 = new GLTFShape("models/Stalagmite_01/Stalagmite_01.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
stalagmite.addComponentOrReplace(gltfShape6)

const verticalMagicRock = new Entity('verticalMagicRock')
engine.addEntity(verticalMagicRock)
verticalMagicRock.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(9, 0, 22.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalMagicRock.addComponentOrReplace(transform22)

const fantasyIronKey = new Entity('fantasyIronKey')
engine.addEntity(fantasyIronKey)
fantasyIronKey.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(9, 7.5, 24.5),
  rotation: new Quaternion(-0.3928474485874176, -0.5879377722740173, 0.39284762740135193, 0.5879378318786621),
  scale: new Vector3(1.5000154972076416, 1.5000085830688477, 1.5000040531158447)
})
fantasyIronKey.addComponentOrReplace(transform23)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape7 = new GLTFShape("models/FloorFantasyRocks_03/FloorFantasyRocks_03.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
entity.addComponentOrReplace(gltfShape7)
const transform24 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform24)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape7)
const transform25 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform25)

const fantasyChest = new Entity('fantasyChest')
engine.addEntity(fantasyChest)
fantasyChest.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(4.5, 0, 21.5),
  rotation: new Quaternion(1.607622285889742e-14, 0.831469714641571, -9.911890685998515e-8, 0.5555701851844788),
  scale: new Vector3(1.0000030994415283, 1, 1.0000030994415283)
})
fantasyChest.addComponentOrReplace(transform26)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(9.5, 0, 3),
  rotation: new Quaternion(-1.473128679282986e-15, 0.4713967442512512, -5.6194867426029305e-8, 0.8819213509559631),
  scale: new Vector3(1.0000064373016357, 1, 1.0000064373016357)
})
signpostTree.addComponentOrReplace(transform27)

const ambientSound = new Entity('ambientSound')
engine.addEntity(ambientSound)
ambientSound.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(3, 0, 26.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ambientSound.addComponentOrReplace(transform28)

const ambientSound2 = new Entity('ambientSound2')
engine.addEntity(ambientSound2)
ambientSound2.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(12.5, 0, 22),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ambientSound2.addComponentOrReplace(transform29)

const ambientSound3 = new Entity('ambientSound3')
engine.addEntity(ambientSound3)
ambientSound3.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(8.5, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ambientSound3.addComponentOrReplace(transform30)

const moodyDeadTree = new Entity('moodyDeadTree')
engine.addEntity(moodyDeadTree)
moodyDeadTree.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(2.5, 0, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
moodyDeadTree.addComponentOrReplace(transform31)
const gltfShape8 = new GLTFShape("models/Tree_Dead_03/Tree_Dead_03.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
moodyDeadTree.addComponentOrReplace(gltfShape8)

const alchemyEquipment = new Entity('alchemyEquipment')
engine.addEntity(alchemyEquipment)
alchemyEquipment.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(3, 1, 14),
  rotation: new Quaternion(-6.438242374938365e-16, -0.6343933343887329, 7.56255715828047e-8, 0.7730104923248291),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
alchemyEquipment.addComponentOrReplace(transform32)
const gltfShape9 = new GLTFShape("models/Lab_Sphere_01/Lab_Sphere_01.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
alchemyEquipment.addComponentOrReplace(gltfShape9)

const alabastron = new Entity('alabastron')
engine.addEntity(alabastron)
alabastron.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(2, 1, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
alabastron.addComponentOrReplace(transform33)
const gltfShape10 = new GLTFShape("models/Vase_03/Vase_03.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
alabastron.addComponentOrReplace(gltfShape10)

const amethyst = new Entity('amethyst')
engine.addEntity(amethyst)
amethyst.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(1.5, 2, 10.5),
  rotation: new Quaternion(-0.20526212453842163, 0.6766589879989624, 0.20526224374771118, -0.6766589879989624),
  scale: new Vector3(1.000003695487976, 1.0000028610229492, 1.0000001192092896)
})
amethyst.addComponentOrReplace(transform34)
const gltfShape11 = new GLTFShape("models/Gem_04/Gem_04.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
amethyst.addComponentOrReplace(gltfShape11)

const bookshelf = new Entity('bookshelf')
engine.addEntity(bookshelf)
bookshelf.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(1.5, 0, 10.5),
  rotation: new Quaternion(-1.0514533376458114e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071067094802856),
  scale: new Vector3(0.9999997615814209, 1, 0.9999997615814209)
})
bookshelf.addComponentOrReplace(transform35)
const gltfShape12 = new GLTFShape("models/Shelf_02/Shelf_02.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
bookshelf.addComponentOrReplace(gltfShape12)

const bluePotion = new Entity('bluePotion')
engine.addEntity(bluePotion)
bluePotion.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(1.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bluePotion.addComponentOrReplace(transform36)
const gltfShape13 = new GLTFShape("models/Potion_02/Potion_02.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
bluePotion.addComponentOrReplace(gltfShape13)

const dawnOfTheCagedMind = new Entity('dawnOfTheCagedMind')
engine.addEntity(dawnOfTheCagedMind)
dawnOfTheCagedMind.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(1.5, 1, 10.5),
  rotation: new Quaternion(0, 0.2902846932411194, -3.4604628496026635e-8, 0.9569403529167175),
  scale: new Vector3(1, 1, 1)
})
dawnOfTheCagedMind.addComponentOrReplace(transform37)
const gltfShape14 = new GLTFShape("models/Book_04/Book_04.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
dawnOfTheCagedMind.addComponentOrReplace(gltfShape14)

const doubloon = new Entity('doubloon')
engine.addEntity(doubloon)
doubloon.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(4, 1, 13.5),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.500002384185791, 1.5, 1.500002384185791)
})
doubloon.addComponentOrReplace(transform38)
const gltfShape15 = new GLTFShape("models/Coin_01/Coin_01.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
doubloon.addComponentOrReplace(gltfShape15)

const doubloon2 = new Entity('doubloon2')
engine.addEntity(doubloon2)
doubloon2.setParent(_scene)
doubloon2.addComponentOrReplace(gltfShape15)
const transform39 = new Transform({
  position: new Vector3(4, 1, 13),
  rotation: new Quaternion(-1.10062582369541e-15, 0.6343932747840881, -7.562556447737734e-8, 0.7730104327201843),
  scale: new Vector3(1.4999998807907104, 1.5, 1.4999998807907104)
})
doubloon2.addComponentOrReplace(transform39)

const doubloon3 = new Entity('doubloon3')
engine.addEntity(doubloon3)
doubloon3.setParent(_scene)
doubloon3.addComponentOrReplace(gltfShape15)
const transform40 = new Transform({
  position: new Vector3(4, 1, 14),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.500002384185791, 1.5, 1.500002384185791)
})
doubloon3.addComponentOrReplace(transform40)

const woodenThrone = new Entity('woodenThrone')
engine.addEntity(woodenThrone)
woodenThrone.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(13.5, 0, 17.5),
  rotation: new Quaternion(1.1404852173768631e-8, -0.3826834261417389, 1.8085662745193076e-8, 0.9238795042037964),
  scale: new Vector3(1.0000088214874268, 1, 1.0000088214874268)
})
woodenThrone.addComponentOrReplace(transform41)
const gltfShape16 = new GLTFShape("models/WoodBigChair_01/WoodBigChair_01.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
woodenThrone.addComponentOrReplace(gltfShape16)

const stalagmite2 = new Entity('stalagmite2')
engine.addEntity(stalagmite2)
stalagmite2.setParent(_scene)
stalagmite2.addComponentOrReplace(gltfShape6)
const transform42 = new Transform({
  position: new Vector3(9, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.294999599456787, 6.75, 1.9999996423721313)
})
stalagmite2.addComponentOrReplace(transform42)

const stalagmite3 = new Entity('stalagmite3')
engine.addEntity(stalagmite3)
stalagmite3.setParent(_scene)
stalagmite3.addComponentOrReplace(gltfShape6)
const transform43 = new Transform({
  position: new Vector3(9, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.294999599456787, 6.75, 1.9999996423721313)
})
stalagmite3.addComponentOrReplace(transform43)

const pirateLever2 = new Entity('pirateLever2')
engine.addEntity(pirateLever2)
pirateLever2.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(12.5, 0, 17),
  rotation: new Quaternion(-0.026695910841226578, -0.04994472488760948, 0.005337513983249664, 0.9983808994293213),
  scale: new Vector3(0.49999967217445374, 0.5000001192092896, 0.5000001192092896)
})
pirateLever2.addComponentOrReplace(transform44)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script1.spawn(scroll, {"text":"Choose wisely...","fontSize":36}, createChannel(channelId, scroll, channelBus))
script2.spawn(verticalMagicRock, {"distance":10,"speed":20,"autoStart":false,"onReachEnd":[{"entityName":"verticalMagicRock","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalMagicRock","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalMagicRock, channelBus))
script3.spawn(fantasyIronKey, {"target":"fantasyChest","respawns":true,"onUse":[{"entityName":"fantasyChest","actionId":"open","values":{}}],"onEquip":[]}, createChannel(channelId, fantasyIronKey, channelBus))
script4.spawn(fantasyChest, {"onClickText":"Open/Close","onClick":[],"onOpen":[{"entityName":"fantasyIronKey","actionId":"respawn","values":{}}],"onClose":[]}, createChannel(channelId, fantasyChest, channelBus))
script5.spawn(signpostTree, {"text":"Rest, traveler","fontSize":20}, createChannel(channelId, signpostTree, channelBus))
script6.spawn(ambientSound, {"sound":"Birds","active":true,"loop":true}, createChannel(channelId, ambientSound, channelBus))
script6.spawn(ambientSound2, {"sound":"Field","active":true,"loop":true}, createChannel(channelId, ambientSound2, channelBus))
script6.spawn(ambientSound3, {"sound":"Swamp","active":true,"loop":true}, createChannel(channelId, ambientSound3, channelBus))
script7.spawn(pirateLever2, {"onActivate":[{"entityName":"verticalMagicRock","actionId":"goToEnd","values":{}}],"onDeactivate":[{"entityName":"verticalMagicRock","actionId":"goToStart","values":{}}]}, createChannel(channelId, pirateLever2, channelBus))